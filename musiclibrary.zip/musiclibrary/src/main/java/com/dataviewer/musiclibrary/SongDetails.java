package com.dataviewer.musiclibrary;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SongDetails {
    public String id;
    public boolean readable;
    public String title;
    @SerializedName("title_short")
    public String titleShort;
    @SerializedName("title_version")
    public String titleVersion;
    public String isrc;
    public String link;
    public String share;
    public int duration;
    @SerializedName("track_position")
    public int trackPosition;
    @SerializedName("disk_number")
    public int diskNumber;
    public int rank;
    @SerializedName("release_date")
    public String releaseDate;
    @SerializedName("explicit_lyrics")
    public boolean explicitLyrics;
    @SerializedName("explicit_content_lyrics")
    public int explicitContentLyrics;
    @SerializedName("explicit_content_cover")
    public int explicitContentCover;
    public String preview;
    public double bpm;
    public double gain;
    @SerializedName("available_countries")
    public List<String> availableCountries;
    public List<Contributor> contributors;
    @SerializedName("md5_image")
    public String md5Image;
    public Artist artist;
    public Album album;
    public String type;

    public SongDetails(String id, boolean readable, String title, String titleShort, String titleVersion, String isrc,
                       String link, String share, int duration, int trackPosition, int diskNumber, int rank,
                       String releaseDate, boolean explicitLyrics, int explicitContentLyrics,
                       int explicitContentCover, String preview, double bpm, double gain,
                       List<String> availableCountries, List<Contributor> contributors, String md5Image,
                       Artist artist, Album album, String type) {
        this.id = id;
        this.readable = readable;
        this.title = title;
        this.titleShort = titleShort;
        this.titleVersion = titleVersion;
        this.isrc = isrc;
        this.link = link;
        this.share = share;
        this.duration = duration;
        this.trackPosition = trackPosition;
        this.diskNumber = diskNumber;
        this.rank = rank;
        this.releaseDate = releaseDate;
        this.explicitLyrics = explicitLyrics;
        this.explicitContentLyrics = explicitContentLyrics;
        this.explicitContentCover = explicitContentCover;
        this.preview = preview;
        this.bpm = bpm;
        this.gain = gain;
        this.availableCountries = availableCountries;
        this.contributors = contributors;
        this.md5Image = md5Image;
        this.artist = artist;
        this.album = album;
        this.type = type;
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isReadable() {
        return readable;
    }

    public void setReadable(boolean readable) {
        this.readable = readable;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitleShort() {
        return titleShort;
    }

    public void setTitleShort(String titleShort) {
        this.titleShort = titleShort;
    }

    public String getTitleVersion() {
        return titleVersion;
    }

    public void setTitleVersion(String titleVersion) {
        this.titleVersion = titleVersion;
    }

    public String getIsrc() {
        return isrc;
    }

    public void setIsrc(String isrc) {
        this.isrc = isrc;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getShare() {
        return share;
    }

    public void setShare(String share) {
        this.share = share;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getTrackPosition() {
        return trackPosition;
    }

    public void setTrackPosition(int trackPosition) {
        this.trackPosition = trackPosition;
    }

    public int getDiskNumber() {
        return diskNumber;
    }

    public void setDiskNumber(int diskNumber) {
        this.diskNumber = diskNumber;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public boolean isExplicitLyrics() {
        return explicitLyrics;
    }

    public void setExplicitLyrics(boolean explicitLyrics) {
        this.explicitLyrics = explicitLyrics;
    }

    public int getExplicitContentLyrics() {
        return explicitContentLyrics;
    }

    public void setExplicitContentLyrics(int explicitContentLyrics) {
        this.explicitContentLyrics = explicitContentLyrics;
    }

    public int getExplicitContentCover() {
        return explicitContentCover;
    }

    public void setExplicitContentCover(int explicitContentCover) {
        this.explicitContentCover = explicitContentCover;
    }

    public String getPreview() {
        return preview;
    }

    public void setPreview(String preview) {
        this.preview = preview;
    }

    public double getBpm() {
        return bpm;
    }

    public void setBpm(double bpm) {
        this.bpm = bpm;
    }

    public double getGain() {
        return gain;
    }

    public void setGain(double gain) {
        this.gain = gain;
    }

    public List<String> getAvailableCountries() {
        return availableCountries;
    }

    public void setAvailableCountries(List<String> availableCountries) {
        this.availableCountries = availableCountries;
    }

    public List<Contributor> getContributors() {
        return contributors;
    }

    public void setContributors(List<Contributor> contributors) {
        this.contributors = contributors;
    }

    public String getMd5Image() {
        return md5Image;
    }

    public void setMd5Image(String md5Image) {
        this.md5Image = md5Image;
    }

    public Artist getArtist() {
        return artist;
    }

    public void setArtist(Artist artist) {
        this.artist = artist;
    }

    public Album getAlbum() {
        return album;
    }

    public void setAlbum(Album album) {
        this.album = album;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}

