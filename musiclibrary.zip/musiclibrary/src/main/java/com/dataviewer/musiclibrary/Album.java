package com.dataviewer.musiclibrary;

import com.google.gson.annotations.SerializedName;

public class Album {
    public int id;
    public String title;
    public String link;
    public String cover;
    @SerializedName("cover_small")
    public String coverSmall;
    @SerializedName("cover_medium")
    public String coverMedium;
    @SerializedName("cover_big")
    public String coverBig;
    @SerializedName("cover_xl")
    public String coverXl;
    @SerializedName("md5_image")
    public String md5Image;
    @SerializedName("release_date")
    public String releaseDate;
    public String tracklist;
    public String type;

    public Album(int id, String title, String link, String cover, String coverSmall, String coverMedium,
                 String coverBig, String coverXl, String md5Image, String releaseDate, String tracklist,
                 String type) {
        this.id = id;
        this.title = title;
        this.link = link;
        this.cover = cover;
        this.coverSmall = coverSmall;
        this.coverMedium = coverMedium;
        this.coverBig = coverBig;
        this.coverXl = coverXl;
        this.md5Image = md5Image;
        this.releaseDate = releaseDate;
        this.tracklist = tracklist;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getCoverSmall() {
        return coverSmall;
    }

    public void setCoverSmall(String coverSmall) {
        this.coverSmall = coverSmall;
    }

    public String getCoverMedium() {
        return coverMedium;
    }

    public void setCoverMedium(String coverMedium) {
        this.coverMedium = coverMedium;
    }

    public String getCoverBig() {
        return coverBig;
    }

    public void setCoverBig(String coverBig) {
        this.coverBig = coverBig;
    }

    public String getCoverXl() {
        return coverXl;
    }

    public void setCoverXl(String coverXl) {
        this.coverXl = coverXl;
    }

    public String getMd5Image() {
        return md5Image;
    }

    public void setMd5Image(String md5Image) {
        this.md5Image = md5Image;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getTracklist() {
        return tracklist;
    }

    public void setTracklist(String tracklist) {
        this.tracklist = tracklist;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
