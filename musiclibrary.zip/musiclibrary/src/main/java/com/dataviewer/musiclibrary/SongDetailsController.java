package com.dataviewer.musiclibrary;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

public class SongDetailsController {
    public Label contributors;
    private MediaPlayer mediaPlayer;
    public String previewURL;
    public boolean isPlaying = false;
    public ImageView songArtwork;
    public Label songTitle;
    public Label artist;
    public Label album;
    public Label releaseDate;
    public Label explicit;
    public Label duration;
    public Button playPreviewButton;


    public void setSongArtwork(String artwork) {
        if (artwork != null){
            Image image = new Image(artwork);
            songArtwork.setImage(image);
        }
    }

    public void setSongTitle(String title) {
       songTitle.setText(title);
    }

    public void setArtistValue(String artistValue) {
      artist.setText(artistValue);
    }

    public void setAlbumValue(String albumValue) {
        album.setText(albumValue);
    }

    public void setReleaseDate(String releaseDateValue) {
        releaseDate.setText(releaseDateValue);
    }

    public void setExplicit(boolean isExplicit) {
        if (isExplicit){
            explicit.setText("Yes");
        }else {
            explicit.setText("No");
        }
    }

    public void setDuration(String durationValue) {
        duration.setText(durationValue);
    }

    public void setPreviewURL(String pURL){
        this.previewURL = pURL;
    }

    public void setContributors(String cont) {
        contributors.setText(cont);
    }

    public void playPreview() {
        if (isPlaying){
            mediaPlayer.stop();
            playPreviewButton.setText("Play Preview");
        } else {
            Media media = new Media(this.previewURL);
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.setOnEndOfMedia(() -> {
                playPreviewButton.setText("Play Preview");
                isPlaying = false;
            });
            mediaPlayer.play();
            playPreviewButton.setText("Playing Preview");
        }

        isPlaying = !isPlaying;
    }

    public void switchToListView() {
        if (mediaPlayer != null){
            mediaPlayer.stop();
        }
        Stage stage = (Stage) playPreviewButton.getScene().getWindow();
        stage.setTitle("Music Library");
        ViewSwitcher<MusicLibraryController> viewSwitcher = new ViewSwitcher<>(stage);
        viewSwitcher.switchView("listview.fxml");
    }
}
