package com.dataviewer.musiclibrary;

import com.google.gson.annotations.SerializedName;

public class Contributor {
    public int id;
    public String name;
    public String link;
    public String share;
    public String picture;
    @SerializedName("picture_small")
    public String pictureSmall;
    @SerializedName("picture_medium")
    public String pictureMedium;
    @SerializedName("picture_big")
    public String pictureBig;
    @SerializedName("picture_xl")
    public String pictureXl;
    public boolean radio;
    public String tracklist;
    public String type;
    public String role;

    public Contributor(int id, String name, String link, String share, String picture, String pictureSmall,
                       String pictureMedium, String pictureBig, String pictureXl, boolean radio, String tracklist,
                       String type, String role) {
        this.id = id;
        this.name = name;
        this.link = link;
        this.share = share;
        this.picture = picture;
        this.pictureSmall = pictureSmall;
        this.pictureMedium = pictureMedium;
        this.pictureBig = pictureBig;
        this.pictureXl = pictureXl;
        this.radio = radio;
        this.tracklist = tracklist;
        this.type = type;
        this.role = role;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getShare() {
        return share;
    }

    public void setShare(String share) {
        this.share = share;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getPictureSmall() {
        return pictureSmall;
    }

    public void setPictureSmall(String pictureSmall) {
        this.pictureSmall = pictureSmall;
    }

    public String getPictureMedium() {
        return pictureMedium;
    }

    public void setPictureMedium(String pictureMedium) {
        this.pictureMedium = pictureMedium;
    }

    public String getPictureBig() {
        return pictureBig;
    }

    public void setPictureBig(String pictureBig) {
        this.pictureBig = pictureBig;
    }

    public String getPictureXl() {
        return pictureXl;
    }

    public void setPictureXl(String pictureXl) {
        this.pictureXl = pictureXl;
    }

    public boolean isRadio() {
        return radio;
    }

    public void setRadio(boolean radio) {
        this.radio = radio;
    }

    public String getTracklist() {
        return tracklist;
    }

    public void setTracklist(String tracklist) {
        this.tracklist = tracklist;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
