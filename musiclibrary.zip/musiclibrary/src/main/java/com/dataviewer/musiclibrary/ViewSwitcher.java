package com.dataviewer.musiclibrary;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;

public class ViewSwitcher<T> {

    private Stage stage;
    private T controller;

    public ViewSwitcher(Stage stage) {
        this.stage = stage;
    }

    public void switchView(String fxmlFile) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(ViewSwitcher.class.getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            controller = fxmlLoader.getController();
            Scene scene = new Scene(root,680, 530);
            scene.getStylesheets().add(getClass().getResource("musiclibrarystyles.css").toExternalForm());
            stage.getIcons().add(new Image(getClass().getResourceAsStream("music.png")));
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public T getController() {
        return controller;
    }

}
